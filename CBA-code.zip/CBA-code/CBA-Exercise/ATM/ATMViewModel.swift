//
//  PinViewModel.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 28/2/21.
//

import Foundation
class ATMViewModel: NSObject {
    var atmObj:Atm?
    
}
