//
//  PinViewController.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 28/2/21.
//

import UIKit
import SnapKit
import MapKit

class ATMViewController: UIViewController {
    
    let viewModel = ATMViewModel()
    
    //MapView
    let mapView = MKMapView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        
        self.title = "ATM Location"
        self.setupMap()
    }
    
    func setupMap()  {
        self.view.addSubview(self.mapView)
        
        self.mapView.mapType = .standard
        self.mapView.isZoomEnabled = true
        self.mapView.isScrollEnabled = true
        self.mapView.delegate = self
        
        self.mapView.center = self.view.center
        self.mapView.snp.makeConstraints { make in
            make.top.leading.trailing.bottom.equalToSuperview()
        }
        self.showAnnotation()
    }
    
    func showAnnotation() {
        let annotation = MKPointAnnotation()
        annotation.title = self.viewModel.atmObj?.name
        annotation.coordinate = CLLocationCoordinate2D(latitude: self.viewModel.atmObj?.location.lat ?? 0, longitude: self.viewModel.atmObj?.location.lng ?? 0)
        self.mapView.addAnnotation(annotation)
        self.mapView.showAnnotations(self.mapView.annotations, animated: true)
    }
}

extension ATMViewController: MKMapViewDelegate {
    
    //Mapview Delegate
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if !(annotation is MKPointAnnotation) {
            return nil
        }
        
        let annotationIdentifier = "AnnotationIdentifier"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: annotationIdentifier)
        
        if annotationView == nil {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: annotationIdentifier)
            annotationView!.canShowCallout = true
        }
        else {
            annotationView!.annotation = annotation
        }
        
        let pinImage = UIImage(named: "Pin")
        annotationView!.image = pinImage
        
        return annotationView
    }
}
