//
//  APIManager.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 27/2/21.
//

import UIKit

struct RuntimeError: Error {
    let message: String
    init(_ message: String) {
        self.message = message
    }
    public var localizedDescription: String {
        return message
    }
}

enum APIResult {
    case success(String)
    case failure(String)
}

let TIME_OUT_INTERVAL = 120

private func getHeaderData() -> Dictionary<String, String> {
    //Set Header Params
    let params = [String:String]()
    return params
}


class NetworkManager: NSObject {
    
    static let BaseRequestSharedInstance = NetworkManager()
    var taskPost: URLSessionTask? = nil
    //MARK: - WS CALLS Methods
    
    func GETRequset(showLoader: Bool, url:String, isProgress:Bool = true, completionHandler:@escaping (APIResult?) -> Void) {
        
        let headerData = getHeaderData()
        
        var request = URLRequest(url: URL(string: url)!)
        request.timeoutInterval = TimeInterval(TIME_OUT_INTERVAL)
        request.httpMethod = "GET"
        
        request.allHTTPHeaderFields = headerData
        
        let task = URLSession.shared.dataTask(with: request) { dataRecieved, response, error in
            
            print("##############################################################################")
            print("URL: \(String(describing: url))")
            print("METHOD: Get")
            print("HEADER: \(String(describing: headerData))")
            
            guard let _ = dataRecieved, error == nil else {
                print("O/P error=\(error.debugDescription)")
                DispatchQueue.main.async {
                    completionHandler(.failure(error!.localizedDescription ))
                }
                return
            }
            
            self.handleResponse(data:dataRecieved, response:response, isProgress: isProgress, error:error, success: { (response) in
                print("##############################################################################")
                DispatchQueue.main.async {
                    completionHandler(.success(response! as! String))
                }
                
            }, failed: { (errorDescription) in
                
                DispatchQueue.main.async {
                    if(errorDescription.debugDescription == "The network connection was lost.") {
                        self.GETRequset(showLoader: showLoader, url: url, isProgress: isProgress,completionHandler: completionHandler)
                    }
                    else {
                        completionHandler(.failure(errorDescription as! String))
                    }
                }
                
            })
            
        }
        
        task.resume()
        
    }
    
    private func handleResponse(data:Data? , response:URLResponse? ,isProgress:Bool = true , error:Error?, success:@escaping (AnyObject?) -> Void, failed:@escaping (AnyObject?) -> Void) {
        let httpStatus = response as? HTTPURLResponse
        let statusCode = httpStatus?.statusCode
        
        let responseString = String(data: data! , encoding: .utf8)

        switch statusCode! as NSNumber {
        case 200,201:
            success(responseString as AnyObject)
            
        case 404:
            success(responseString as AnyObject)
            
        default:
            failed(responseString as AnyObject)
        }
    }
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
                
                print("error in web service \(text)")
            }
        }
        return nil
    }


    func cancelTask()  {
    }

}

