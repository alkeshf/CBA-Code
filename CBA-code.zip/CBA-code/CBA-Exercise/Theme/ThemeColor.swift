//
//  ThemeColor.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 27/2/21.
//

import UIKit

public enum ThemeColor: String {
    case cellDescriptionLabel
    case cellValueLabel
    case cellBackground
    case tableSectionHeaderBackground
    case headerMainBackground
    case headerTopBackground
    case headerBottomBackground
    case greyText
    case accountText
    
    public var value: UIColor {
        switch self {
        case .cellDescriptionLabel, .cellValueLabel:
            return UIColor(named: "viewBlack")!
        case .cellBackground, .headerTopBackground:
            return UIColor(named: "viewWhite")!
        case .tableSectionHeaderBackground:
            return UIColor(named: "tableSectionHeaderBackground")!
        case .headerMainBackground:
            return UIColor(named: "headerMainBackground")!
        case .headerBottomBackground:
            return UIColor(named: "headerBottomBackground")!
        case .greyText:
            return UIColor(named: "greyText")!
        case .accountText:
            return UIColor(named: "accountText")!
        }
    }
}
