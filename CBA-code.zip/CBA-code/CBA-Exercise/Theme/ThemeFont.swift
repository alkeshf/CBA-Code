//
//  ThemeFont.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 27/2/21.
//

import UIKit

public enum ThemeFont: String {
    case accountText
    case descriptionText
    case amountText
    
    public var value: UIFont {
        switch self {
        case .accountText:
            return UIFont(name: "HelveticaNeue-Light", size: 18)!
        case .descriptionText:
            return UIFont(name: "HelveticaNeue", size: 17)!
        case .amountText:
            return UIFont(name: "HelveticaNeue-Bold", size: 17)!
        }
    }
}
