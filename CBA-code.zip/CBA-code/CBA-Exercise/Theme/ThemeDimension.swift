//
//  ThemeDimension.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 27/2/21.
//

import UIKit

public enum ThemeDimension: String {
    
    case leadingTrailingPadding
    case betweenPadding
    case smallPadding
    case largePadding
    case separatorHeight
    case iconSize
    case tableHeaderHeight
    
    public var value: CGFloat {
        switch self {
        case .leadingTrailingPadding:
            return 10
        case .betweenPadding:
            return 20
        case .smallPadding:
            return 5
        case .largePadding:
            return 70
        case .separatorHeight:
            return 0.5
        case .iconSize:
            return 32
        case .tableHeaderHeight:
            return 150
        }
    }
    
}
