//
//  AccountDetailsSectionHeaderView.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 28/2/21.
//

import UIKit
import SnapKit

class AccountDetailsSectionHeaderView: UITableViewCell {
    
    let date = UILabel()
    let timeSpan = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.contentView.addSubview(date)
        self.contentView.addSubview(timeSpan)
        
        self.contentView.backgroundColor = ThemeColor.tableSectionHeaderBackground.value
        
        self.setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupLayout() {
        date.textAlignment = .left
        timeSpan.textAlignment = .right
        
        date.snp.makeConstraints { make in
            make.leading.top.bottom.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
            make.top.equalToSuperview()
        }
        
        timeSpan.snp.makeConstraints { make in
            make.trailing.top.bottom.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
            make.centerY.equalToSuperview()
        }
    }
        
}
