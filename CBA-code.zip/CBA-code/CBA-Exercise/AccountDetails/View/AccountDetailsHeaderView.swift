//
//  AccountDetailsHeaderView.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 28/2/21.
//

import UIKit

class AccountDetailsHeaderView: UIView {
    
    let contentView  = UIView()
    let topView = UIView()
    let icon = UIImageView()
    let access = UILabel()
    let accountNumber = UILabel()
    let bottomView = UIView()
    let separator = UIView()
    let availableFundsTitle = UILabel()
    let availableFundsValue = UILabel()
    let accountBalanceTitle = UILabel()
    let accountBalanceValue = UILabel()
    
    public required init() {
        super.init(frame: .zero)
        
        self.setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupLayout() {
    
        self.addSubview(self.contentView)
        self.contentView.addSubview(self.topView)
        self.topView.addSubview(self.icon)
        self.topView.addSubview(self.access)
        self.topView.addSubview(self.accountNumber)
        self.contentView.addSubview(self.bottomView)
        self.bottomView.addSubview(self.separator)
        self.bottomView.addSubview(self.accountBalanceTitle)
        self.bottomView.addSubview(self.accountBalanceValue)
        self.bottomView.addSubview(self.availableFundsTitle)
        self.bottomView.addSubview(self.availableFundsValue)
        
        self.backgroundColor = ThemeColor.headerMainBackground.value
        
        self.snp.makeConstraints { make in
            make.height.equalTo(ThemeDimension.tableHeaderHeight.value)
        }
        
        //contentView
        self.contentView.snp.makeConstraints { make in
            make.leading.trailing.top.bottom.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
        }
        
        //topView
        self.topView.snp.makeConstraints { make in
            make.top.left.right.equalToSuperview()
        }
        self.topView.backgroundColor = ThemeColor.headerTopBackground.value
        
        //icon
        self.icon.snp.makeConstraints { make in
            make.leading.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
            make.centerY.equalToSuperview()
        }
        self.icon.image = UIImage(named:"accountstransactional")
        
        
        //access
        self.access.snp.makeConstraints { make in
            make.leading.equalTo(self.icon.snp.trailing).offset(ThemeDimension.betweenPadding.value)
            make.top.equalTo(self.icon)
        }
        self.access.font = ThemeFont.accountText.value
        self.access.textColor = ThemeColor.accountText.value
        
        //accountNumber
        self.accountNumber.snp.makeConstraints { make in
            make.leading.equalTo(self.icon.snp.trailing).offset(ThemeDimension.betweenPadding.value)
            make.top.equalTo(self.access.snp.bottom).offset(ThemeDimension.smallPadding.value)
            make.bottom.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
        }
        self.accountNumber.textColor = ThemeColor.greyText.value
        
        //bottomView
        self.bottomView.snp.makeConstraints { make in
            make.bottom.left.right.equalToSuperview()
            make.top.equalTo(self.topView.snp.bottom)
        }
        self.bottomView.backgroundColor = ThemeColor.headerBottomBackground.value
        
        //separator
        self.separator.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(ThemeDimension.separatorHeight.value)
        }
        self.separator.backgroundColor = ThemeColor.greyText.value
        self.separator.alpha = 0.3
        
        //availableFundsTitle
        self.availableFundsTitle.snp.makeConstraints { make in
            make.leading.equalTo(self.access)
            make.top.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
        }
        self.availableFundsTitle.textColor = ThemeColor.greyText.value
        
        //accountBalanceTitle
        self.accountBalanceTitle.snp.makeConstraints { make in
            make.leading.equalTo(self.availableFundsTitle)
            make.top.equalTo(self.availableFundsTitle.snp.bottom).offset(ThemeDimension.smallPadding.value)
            make.bottom.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
        }
        self.accountBalanceTitle.textColor = ThemeColor.greyText.value
        
        //availableFundsValue
        self.availableFundsValue.snp.makeConstraints { make in
            make.trailing.equalToSuperview().inset(ThemeDimension.betweenPadding.value)
            make.top.equalTo(self.availableFundsTitle.snp.top)
        }
        self.availableFundsValue.textColor =  ThemeColor.cellDescriptionLabel.value

        //accountBalanceValue
        self.accountBalanceValue.snp.makeConstraints { make in
            make.leading.equalTo(self.availableFundsValue)
            make.top.equalTo(self.accountBalanceTitle.snp.top)
            make.bottom.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
        }
        self.accountBalanceValue.textColor = ThemeColor.greyText.value
    }
    
    func setupData(accountObj: Account)  {
        
        self.icon.image = UIImage(named:"accountstransactional")
        
        self.access.text = accountObj.accountName
        
        self.accountNumber.text = accountObj.accountNumber
        
        self.availableFundsTitle.text = "Available funds"
        
        self.accountBalanceTitle.text = "Available balance"
        
        self.availableFundsValue.text = String(accountObj.available)
        
        self.accountBalanceValue.text = String(accountObj.balance)
    }
    
}
