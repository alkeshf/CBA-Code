//
//  AccountDetailsCell.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 27/2/21.
//

import UIKit
import SnapKit

class AccountDetailsCell: UITableViewCell {
    
    let transactionDescription = UILabel()
    let amount = UILabel()
    let icon = UIImageView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupLayout() {
        // transactionDescription font color and styling
        transactionDescription.textAlignment = .left
        transactionDescription.textColor = ThemeColor.cellDescriptionLabel.value
        transactionDescription.font = ThemeFont.descriptionText.value
        transactionDescription.numberOfLines = 0
        
        // amount font color and styling
        amount.textAlignment = .left
        amount.textColor = ThemeColor.cellValueLabel.value
        amount.font = ThemeFont.amountText.value
        
                
        contentView.addSubview(self.amount)
        let stackview = UIStackView()
        stackview.axis = .horizontal
        stackview.alignment = .center
        stackview.spacing = ThemeDimension.leadingTrailingPadding.value
        stackview.addArrangedSubview(self.icon)
        stackview.addArrangedSubview(self.transactionDescription)
        contentView.addSubview(stackview)
        
        icon.snp.makeConstraints { make in
            make.leading.equalToSuperview()
            make.centerY.equalToSuperview()
            make.size.equalTo(ThemeDimension.iconSize.value)
        }
        
        amount.snp.makeConstraints { (make) -> Void in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
        }
        
        stackview.snp.makeConstraints { (make) -> Void in
            make.top.bottom.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().inset(ThemeDimension.leadingTrailingPadding.value)
            make.trailing.equalToSuperview().inset(80)
        }
    }
    
    func setupData(transactionObj: Transaction){
        //here we are not calculating date difference and days ago
        transactionDescription.attributedText = transactionObj.description.htmlToAttributedString

        if(transactionObj.amount < 0.0 ){
            //withdraw amount
            amount.text  = "-$\(abs(transactionObj.amount))"
        }else{
            // add amount
            amount.text  = "$\(transactionObj.amount)"
        }

        if(transactionObj.atm != nil){
            print("atm object")
            //atm withdrawal transaction
            self.icon.isHidden = false
            icon.image = UIImage(named:"Location")
            self.icon.tintColor = ThemeColor.cellDescriptionLabel.value
            icon.contentMode = .center
            
        }else{
            self.icon.image = nil
            self.icon.isHidden = true
        }

    }
}

extension String {
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf16,allowLossyConversion: true)
        else { return NSAttributedString() }
        do {
            let attributedString = try NSMutableAttributedString(data: data, options: [NSAttributedString.DocumentReadingOptionKey.documentType:  NSAttributedString.DocumentType.html], documentAttributes: nil)
                attributedString.addAttributes([NSAttributedString.Key.foregroundColor: ThemeColor.cellDescriptionLabel.value, NSAttributedString.Key.font: ThemeFont.descriptionText.value], range: NSRange(
                location: 0,
                length: attributedString.length))
            return attributedString

        } catch
        {
            return NSAttributedString()
        }
    }
}
