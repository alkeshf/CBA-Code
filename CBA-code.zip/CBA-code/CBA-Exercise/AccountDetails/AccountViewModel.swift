//
//  AccountViewModel.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 27/2/21.
//

import Foundation

class AccountViewModel: NSObject {
    var modelObj:AccountDetail!
    let url = "https://www.dropbox.com/s/tewg9b71x0wrou9/data.json?dl=1"
    
    func fetchData(completionHandler: @escaping ((APIResult) -> Void)) {
        NetworkManager().GETRequset(showLoader: true, url: self.url) { (result) in
            switch result {
            case .success(let response):
                self.modelObj = self.convertResponseToModel(text: response)
                completionHandler(.success(""))
            case.failure(let message):
                completionHandler(.failure(message))
                break
            case .none:
                break
            }
        }
    }
    
    func convertResponseToModel(text: String) -> AccountDetail? {
        let decoder = JSONDecoder()
        if let data = text.data(using: .utf8) {
            do {
                let obj = try decoder.decode(AccountDetail.self, from: data)
                return obj
            } catch {
                print(error)
            }
        }
        return nil
    }
    
     public func caluclateProjection() -> (amount: Double, numberOfWeeks: Int?) {
        var amount: Double = 0
        var dates = [Date]()
        
        for transactionObj in self.modelObj.transactions {
            amount = amount + transactionObj.amount
            dates.append(self.dateFromString(dateStr: transactionObj.effectiveDate))
        }
        guard let smallestDate = dates.min() else { return (0.0,0) }
        print(smallestDate)
        guard let largestDate = dates.max() else { return (0.0,0) }
        print(largestDate)
        let components = Calendar.current.dateComponents([.weekOfYear], from: smallestDate, to: largestDate)
        let theNumberOfWeeks = components.weekOfYear
        
        var amountPerWeek = Double(amount) / Double(theNumberOfWeeks ?? 0)
        
        if(amountPerWeek < 0.0 ){
            //withdraw amount
            amountPerWeek  = (abs(amountPerWeek))
        }else{
            // add amount
            amountPerWeek  = -(abs(amountPerWeek))
        }
        
        return (amountPerWeek, theNumberOfWeeks)
    }
    
    func dateFromString(dateStr: String) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US") // set locale to reliable US_POSIX
        dateFormatter.dateFormat = "dd/MM/yyyy"
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")

        return dateFormatter.date(from: dateStr)!
    }
}
