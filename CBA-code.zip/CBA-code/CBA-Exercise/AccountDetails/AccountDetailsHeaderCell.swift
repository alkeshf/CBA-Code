//
//  AccountDetailsHeaderCell.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 28/2/21.
//

import UIKit
import SnapKit

class AccountDetailsSectionHeaderCell: UITableViewCell {
}
