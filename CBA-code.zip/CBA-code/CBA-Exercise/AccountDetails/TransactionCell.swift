//
//  TransactionCell.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 27/2/21.
//

import UIKit
import SnapKit

class AccountDetailsCell: UITableViewCell {
    
    let descriptionLabel = UILabel()
    let amountLabel = UILabel()
    let locationIcon = UIImageView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        
        // descriptionLabel font color and styling
        descriptionLabel.textAlignment = .left
        descriptionLabel.textColor = ThemeColor.cellDescriptionLabel.value
        descriptionLabel.font = .systemFont(ofSize: 12)
        descriptionLabel.numberOfLines = 0
        
        // amountLabel font color and styling
        amountLabel.textAlignment = .left
        amountLabel.textColor = ThemeColor.cellValueLabel.value
        amountLabel.font = .boldSystemFont(ofSize: 12)
        
        // location icon
        locationIcon.image = UIImage(named:"Location")
        locationIcon.isHidden = true
        
        contentView.addSubview(self.descriptionLabel)
        contentView.addSubview(self.amountLabel)
        contentView.addSubview(self.locationIcon)
        
        locationIcon.snp.makeConstraints { make in
            make.leading.equalToSuperview().inset(ThemeDimension.padding.value)
            make.centerY.equalToSuperview()
        }
        
        descriptionLabel.snp.makeConstraints { (make) -> Void in
            make.leading.equalTo(locationIcon.snp.trailing).offset(ThemeDimension.padding.value)
            make.top.equalToSuperview().inset(ThemeDimension.padding.value)
            make.bottom.equalToSuperview().inset(ThemeDimension.padding.value)
        }
        
        amountLabel.snp.makeConstraints { (make) -> Void in
            make.leading.equalTo(descriptionLabel.snp.trailing).offset(ThemeDimension.padding.value)
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().inset(ThemeDimension.padding.value)
        }
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
