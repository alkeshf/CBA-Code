//
//  AccountDetailsViewController.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 27/2/21.
//

import UIKit
import SnapKit

enum NetworkError: Error {
    case badURL
}

class AccountDetailsViewController: UIViewController {
    
    let headerView = AccountDetailsHeaderView()
    let tableView = UITableView()
    let viewModel = AccountViewModel()
    let spinner = UIActivityIndicatorView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = ThemeColor.headerTopBackground.value
        self.spinner.hidesWhenStopped = true
        self.title = "Account details"
        
        self.view.addSubview(self.tableView)
        self.view.addSubview(self.spinner)
        
        self.spinner.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
        }
        self.spinner.startAnimating()
        
        viewModel.fetchData { (result) in
            switch result {
            case .success(_):
                self.setupUI()
                self.tableView.reloadData()
                break
            case .failure(_):
                print(result)
            }
            self.spinner.stopAnimating()
        }
    }
    
    fileprivate func setupUI() {
        
        //setting up tableview delegate datasource and
        //assigning headerview to table's headerview
        self.tableView.dataSource = self
        self.tableView.delegate  = self
        self.tableView.tableHeaderView = self.headerView
        self.headerView.translatesAutoresizingMaskIntoConstraints = false
        self.tableView.tableHeaderView = self.headerView
        self.headerView.centerXAnchor.constraint(equalTo: self.tableView.centerXAnchor).isActive = true
        self.headerView.widthAnchor.constraint(equalTo: self.tableView.widthAnchor).isActive = true
        self.headerView.topAnchor.constraint(equalTo: self.tableView.topAnchor).isActive = true
        self.tableView.tableHeaderView?.layoutIfNeeded()
        self.tableView.tableHeaderView = self.tableView.tableHeaderView
        
        self.headerView.setupData(accountObj: self.viewModel.modelObj.account)
        
        let project = UIBarButtonItem(title: "Projection", style: .plain, target: self, action: #selector(projectionTapped))
        self.navigationItem.rightBarButtonItem = project
        
        self.tableView.snp.makeConstraints { make in
            make.top.leading.trailing.bottom.equalToSuperview()
        }
        
        self.tableView.register(AccountDetailsCell.self, forCellReuseIdentifier: "AccountDetailsCell")
        self.tableView.register(AccountDetailsSectionHeaderView.self, forCellReuseIdentifier: "AccountDetailsSectionHeaderCell")
    }
    
    @objc func projectionTapped() {
        let value: (Double, Int?) = self.viewModel.caluclateProjection()
        
        let alert = UIAlertController(title: "Expense projection", message: "Based on your expenses in \(value.1 ?? 0) weeks, your projected expense for the next 2 weeks is $\(value.0 * 2)", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

extension AccountDetailsViewController: UITableViewDataSource, UITableViewDelegate {
    
    //Tableview datasource and delegate
    func numberOfSections(in tableView: UITableView) -> Int {
        guard let modelObj = viewModel.modelObj else {
            return 0
        }
        return modelObj.filterTransaction.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let modelObj = viewModel.modelObj else { return nil }
        let cell: AccountDetailsSectionHeaderView = tableView.dequeueReusableCell(withIdentifier: "AccountDetailsSectionHeaderCell") as! AccountDetailsSectionHeaderView

        cell.date.text = modelObj.filterTransaction[section]["name"] as? String
        cell.timeSpan.text = modelObj.filterTransaction[section]["timespan"] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let modelObj = viewModel.modelObj else {
            return 0
        }
        return (modelObj.filterTransaction[section]["transactions"]?.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AccountDetailsCell") as? AccountDetailsCell else {
            return UITableViewCell()
        }
        guard let arrTransaction = viewModel.modelObj.filterTransaction[indexPath.section]["transactions"] as? [Transaction] else { return UITableViewCell() }
        cell.setupData(transactionObj: arrTransaction[indexPath.row])
        cell.selectionStyle = .none
        if arrTransaction[indexPath.row].atm == nil {
            cell.isUserInteractionEnabled = false
        } else {
            cell.isUserInteractionEnabled = true
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let controller  = ATMViewController()
        guard let arrTransaction = viewModel.modelObj.filterTransaction[indexPath.section]["transactions"] as? [Transaction] else { return }
        controller.viewModel.atmObj = arrTransaction[indexPath.row].atm!
        navigationController?.pushViewController(controller, animated: true)
    }
}
