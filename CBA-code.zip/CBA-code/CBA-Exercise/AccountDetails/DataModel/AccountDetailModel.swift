//
//  AccountDetailModel.swift
//  CBA-Exercise
//
//  Created by Alkesh Fudani on 27/2/21.
//

import Foundation
class Account: Codable {
    var accountName: String
    var accountNumber: String
    var available: Double
    var balance: Double
}

class Transaction: Codable {
    var id: String
    var effectiveDate: String
    var description: String
    var amount: Double
    var atmId: String?
    var atm: Atm?
    var status: Int = 1
    var strDate:String = ""

    enum CodingKeys : String, CodingKey {
        case id
        case effectiveDate
        case description
        case amount
        case atmId
    }
    
    required init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(String.self, forKey: .id)
        effectiveDate = try values.decode(String.self, forKey: .effectiveDate)
        description = try values.decode(String.self, forKey: .description)
        amount = try values.decode(Double.self, forKey: .amount)
        atmId = try? values.decode(String.self, forKey: .atmId)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy" //Your date format
        //according to date format your date string
        guard let date = dateFormatter.date(from: effectiveDate) else {
            fatalError()
        }
        
        dateFormatter.dateFormat = "dd MMM yyyy" //Your New Date format as per requirement change it own
        strDate = dateFormatter.string(from:date) //pass Date here
        
    }
    
}


class Atm: Codable {
    var id: String
    var name: String
    var address: String
    var location: Locations
}

class Locations: Codable {
    var lat: Double
    var lng: Double
    
}

class AccountDetail: Codable {
    var account: Account
    var atms: [Atm]
    var transactions: [Transaction]
    var pending: [Transaction]
    var filterTransaction: [[String:AnyObject]] = []
    
    enum CodingKeys : String, CodingKey {
        case account
        case transactions
        case pending
        case atms
    }
    
    required init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        account = try values.decode(Account.self, forKey: .account)
        atms = try values.decode([Atm].self, forKey: .atms)
        transactions = try values.decode([Transaction].self, forKey: .transactions)
        pending = try values.decode([Transaction].self, forKey: .pending)
        
        //append pending transaction in transaction list
        for element in pending {
            element.status = 0
            transactions.insert(element, at: 0)
        }
        
        let arrAtmObj = transactions.filter {
            ($0.atmId != nil)
        }
        
        for element in arrAtmObj {
            let AtmObj = atms.filter {
                ($0.id == element.atmId)
            }
            if AtmObj.count >= 1 {
                element.atm = AtmObj[0]
            }
        }
        let groupByTransaction: Dictionary<String, [Transaction]> = Dictionary(grouping: transactions, by: {$0.strDate})
        filterTransaction.removeAll()
        for item in groupByTransaction {
            var dict = [String:AnyObject]()
            
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd MMM yyyy" //Your date format
            //according to date format your date string
            guard let date = dateFormatter.date(from: item.key) else {
                fatalError()
            }
            let calendar = Calendar.current
            dict["timespan"] = "\(calendar.dateComponents([.day], from: date, to: Date()).day!)" + " Days Ago" as AnyObject
            dict["name"] = item.key as AnyObject
            dict["date"] = date as AnyObject
            dict["transactions"] = item.value as AnyObject
            filterTransaction.append(dict)
        }
        
        let ready = filterTransaction.sorted(by: { ($0["date"] as! Date).compare(($1["date"] as! Date)) == .orderedDescending })
        filterTransaction = ready
        
        
    }
}

